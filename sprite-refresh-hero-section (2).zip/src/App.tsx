import React, { useState } from 'react';
import { HeroCanvas } from './components/HeroCanvas';
import { MobileHero } from './components/MobileHero';
import { AboutSection } from './components/AboutSection';
import { FlavorsSection } from './components/FlavorsSection';
import { SpriteCinematicReveal } from './components/SpriteCinematicReveal';

export default function App() {
  const [isPlayingReveal, setIsPlayingReveal] = useState<boolean>(true);
  const [heroTriggerKey, setHeroTriggerKey] = useState<number>(0);

  const handleTransitionStart = () => {
    // Synchronize individual component entrances precisely when the loader aperture starts to bloom open
    setHeroTriggerKey((prev) => prev + 1);
  };

  return (
    <main className="relative w-full min-h-screen bg-[#62b9f3] text-white overflow-x-hidden select-none">
      {/* 
        1. DESKTOP HERO VIEWPORT (md and above)
        Centered, perfectly proportioned 1440x1080 design coordinate system placed flush at the top of the page
        Elevated to z-40 so the bottom atmospheric cloud mask floats in the front-most layer merging seamlessly over section 2
      */}
      <div id="home" className="hidden md:block w-full relative overflow-visible z-40 bg-[#6db2ea]">
        <HeroCanvas revealTrigger={heroTriggerKey} />
      </div>

      {/* 
        2. MOBILE HERO VIEWPORT (mobile aspect ratio / responsive 100dvh)
        Dedicated tailored layout with letter-by-letter kinetic headlines, floating island, CTA, and frosted glass navigation
        Elevated to z-40 so the bottom atmospheric cloud mask floats in the front-most layer merging seamlessly over section 2
      */}
      <div id="mobile-home" className="block md:hidden w-full min-h-screen relative overflow-visible z-40 bg-[#6db2ea]">
        <MobileHero revealTrigger={heroTriggerKey} />
      </div>

      {/* 
        3. ABOUT SECTION (Standard clean section, scroll-driven kinetic manifesto, 4:3 desktop ratio)
        z-10 allows the hero's front-most cloud mask to overlap and merge over the top
      */}
      <div className="relative z-10 w-full overflow-visible">
        <AboutSection />
      </div>

      {/* 
        4. FLAVORS SECTION (1448 x 1086 px exact canvas replication)
      */}
      <div className="relative z-20 w-full overflow-visible">
        <FlavorsSection />
      </div>

      {/* 
        5. GLOBAL FULL-SCREEN CINEMATIC LOADING REVEAL
        Spans the entire website viewport on any device, transitioning seamlessly with a slower, buttery fluid lens aperture
      */}
      {isPlayingReveal && (
        <SpriteCinematicReveal
          onTransitionStart={handleTransitionStart}
          onComplete={() => setIsPlayingReveal(false)}
        />
      )}
    </main>
  );
}
