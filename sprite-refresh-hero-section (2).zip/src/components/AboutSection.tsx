import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ScrollBlur } from './ScrollBlur';
import { BlockTextReveal } from './BlockTextReveal';
import { ParticleText } from './ParticleText';

const ABOUT_BG_IMAGE = 'https://res.cloudinary.com/hm4hiju8/image/upload/v1787807893/629618799_1787807879317356.jpg';

export const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  // Parallax scroll scrub linked strictly to normalized scroll progress
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start 85%', 'end 15%'],
  });

  // Layered parallax scroll offsets
  const bgY = useTransform(scrollYProgress, [0, 1], [-70, 70]);
  const textGroupY = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const stickerScrollY = useTransform(scrollYProgress, [0, 1], [20, -20]);

  // Dynamic Scroll Highlighting transforms for each line
  const badgeOpacity = useTransform(scrollYProgress, [0.35, 0.40, 0.56, 0.60], [0.30, 0.38, 1, 1]);
  const badgeScale = useTransform(scrollYProgress, [0.40, 0.56], [0.94, 1]);
  const badgeShadow = useTransform(
    scrollYProgress,
    [0.40, 0.56],
    [
      '0px 2px 8px rgba(0, 0, 0, 0.08)',
      '0px 12px 32px rgba(0, 0, 0, 0.20), 0px 3px 8px rgba(0, 0, 0, 0.10)',
    ]
  );

  // Depth-of-field blurred bokeh bubbles parallax scrub
  const bubbleForegroundY = useTransform(scrollYProgress, [0, 1], [120, -120]);
  const bubbleMidgroundY = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const bubbleBackgroundY = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative z-10 w-full aspect-[9/16] md:aspect-[4/3] md:min-h-[780px] bg-[#6db2ea] text-white flex flex-col items-center justify-center select-none overflow-visible py-12 md:py-0"
    >
      {/* 
        ========================================================================
        1. ATMOSPHERIC SKY & CLOUDS BACKGROUND WITH PARALLAX BLUR
        ========================================================================
      */}
      <ScrollBlur
        scrollProgress={scrollYProgress}
        maxBlur={6}
        maxScale={1.05}
        parallaxOffset={50}
        direction="focus-center"
        className="absolute -inset-16 w-[calc(100%+128px)] h-[calc(100%+128px)] pointer-events-none z-0 overflow-hidden"
      >
        <motion.div style={{ y: bgY }} className="w-full h-full">
          <img
            src={ABOUT_BG_IMAGE}
            alt="Atmospheric Clouds and Sky"
            className="w-full h-full object-cover object-center opacity-100"
            crossOrigin="anonymous"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-sky-400/15 via-transparent to-[#559fda]/25 pointer-events-none" />
        </motion.div>
      </ScrollBlur>

      {/* 
        ========================================================================
        2. INTERACTIVE PARTICLE TEXT CANVAS (SPRITE CITRUS & BUBBLE PARTICLES)
        Positioned dynamically behind/around text with cursor hover dispersal
        ========================================================================
      */}
      <div className="absolute inset-0 z-5 pointer-events-auto flex items-center justify-center opacity-40 hover:opacity-85 transition-opacity duration-500">
        <ParticleText
          text="SPRITE"
          className="w-full h-[60%] max-w-4xl"
          particleSize={2.8}
          interactive={true}
        />
      </div>

      {/* 
        Soft bottom blending gradient into Flavors section below
      */}
      <div
        className="absolute bottom-0 left-0 right-0 h-28 sm:h-36 md:h-48 pointer-events-none z-10"
        style={{
          background:
            'linear-gradient(to top, rgba(98, 185, 243, 0.85) 0%, rgba(98, 185, 243, 0.4) 45%, rgba(98, 185, 243, 0) 100%)',
        }}
      />

      {/* 
        ========================================================================
        3. BLURRED BUBBLE PARTICLES (DEPTH OF FIELD PARALLAX)
        ========================================================================
      */}
      {/* Layer A: Heavy Foreground Blurred Bubble */}
      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute top-[8%] left-[4%] sm:left-[8%] pointer-events-none z-10"
      >
        <div
          className="w-32 h-32 sm:w-44 sm:h-44 md:w-56 md:h-56 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
          }}
        >
          <div className="absolute top-4 left-6 w-10 h-5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-6 right-8 w-5 h-5 rounded-full bg-white/40" />
        </div>
      </motion.div>

      {/* Layer B: Midground Soft-Blurred Bubble */}
      <motion.div
        style={{ y: bubbleMidgroundY }}
        className="absolute top-[16%] right-[5%] sm:right-[10%] pointer-events-none z-10"
      >
        <div
          className="w-24 h-24 sm:w-36 sm:h-36 md:w-44 md:h-44 rounded-full bg-white/22 border border-white/35 shadow-[inset_0_4px_14px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(4px)',
            WebkitBackdropFilter: 'blur(4px)',
          }}
        >
          <div className="absolute top-3 left-4 w-8 h-4 rounded-full bg-white/75 -rotate-45" />
          <div className="absolute bottom-3 right-5 w-4 h-4 rounded-full bg-white/35" />
        </div>
      </motion.div>

      {/* Layer C: Deep Background Small Blurred Bubble */}
      <motion.div
        style={{ y: bubbleBackgroundY }}
        className="absolute bottom-[14%] left-[8%] sm:left-[14%] pointer-events-none z-10"
      >
        <div
          className="w-16 h-16 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-full bg-white/25 border border-white/40 shadow-[inset_0_2px_10px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(3px)',
          }}
        >
          <div className="absolute top-2 left-3 w-5 h-2.5 rounded-full bg-white/80 -rotate-45" />
        </div>
      </motion.div>

      {/* Layer D: Heavy Foreground Blurred Bubble */}
      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute bottom-[8%] right-[4%] sm:right-[8%] pointer-events-none z-10"
      >
        <div
          className="w-28 h-28 sm:w-40 sm:h-40 md:w-52 md:h-52 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(7px)',
          }}
        >
          <div className="absolute top-4 left-5 w-9 h-4.5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-5 right-6 w-4 h-4 rounded-full bg-white/30" />
        </div>
      </motion.div>

      {/* 
        ========================================================================
        4. TYPOGRAPHY WITH BLOCK TEXT REVEAL & DYNAMIC SCROLL ANIMATIONS
        ========================================================================
      */}
      <motion.div
        style={{ y: textGroupY }}
        className="relative z-30 w-full max-w-5xl px-4 sm:px-6 lg:px-8 py-8 sm:py-16 md:py-0 landscape:max-md:-translate-y-[15px] flex flex-col items-center justify-center text-center tracking-normal"
      >
        {/* LINE 1: STIR UP YOUR with Sprite Lemon-Lime Block Reveal */}
        <BlockTextReveal
          progress={scrollYProgress}
          range={[0.06, 0.28]}
          blockColor="#D8FA00"
          className="w-full"
        >
          <h2
            className="w-full font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white"
            style={{
              textShadow: '0px 3px 8px rgba(0, 0, 0, 0.18), 0px 10px 28px rgba(0, 0, 0, 0.12)',
            }}
          >
            STIR UP YOUR
          </h2>
        </BlockTextReveal>

        {/* LINE 2: FEARLESS PAST AND with Sprite Green Block Reveal */}
        <BlockTextReveal
          progress={scrollYProgress}
          range={[0.22, 0.44]}
          blockColor="#00A850"
          className="w-full mt-1 sm:mt-2"
        >
          <h2
            className="w-full font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white"
            style={{
              textShadow: '0px 3px 8px rgba(0, 0, 0, 0.18), 0px 10px 28px rgba(0, 0, 0, 0.12)',
            }}
          >
            FEARLESS PAST AND
          </h2>
        </BlockTextReveal>

        {/* LINE 3: ICONIC SPRITE BRAND PILL [FIRE UP] */}
        <motion.div
          style={{ y: stickerScrollY }}
          className="my-3 sm:my-5 md:my-7 z-30 inline-flex items-center justify-center"
        >
          <motion.div
            style={{
              opacity: badgeOpacity,
              scale: badgeScale,
              boxShadow: badgeShadow,
            }}
            className="relative inline-flex items-center gap-2.5 sm:gap-4 md:gap-5 px-7 sm:px-12 md:px-16 py-2 sm:py-3 md:py-3.5 rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E9FF47] to-[#D8FA00] text-[#003816] font-lilita text-[clamp(1.75rem,7vw,2.4rem)] sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl uppercase tracking-wide border border-white/70 select-none overflow-hidden"
          >
            {/* Ambient inner rim reflection */}
            <div className="absolute inset-0 rounded-full shadow-[inset_0_1.5px_2px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,50,20,0.12)] pointer-events-none" />

            {/* Left Citrus Spark Star */}
            <svg
              className="w-4 h-4 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#003816]/75 fill-current shrink-0 transform -rotate-12"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M12 0L14.4 9.6L24 12L14.4 14.4L12 24L9.6 14.4L0 12L9.6 9.6L12 0Z" />
            </svg>

            {/* Core Wordmark */}
            <span className="relative z-10 block leading-none tracking-[0.03em] transform translate-y-[2px]">
              FIRE UP
            </span>

            {/* Right Citrus Spark Star */}
            <svg
              className="w-4 h-4 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#003816]/75 fill-current shrink-0 transform rotate-12"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M12 0L14.4 9.6L24 12L14.4 14.4L12 24L9.6 14.4L0 12L9.6 9.6L12 0Z" />
            </svg>
          </motion.div>
        </motion.div>

        {/* LINE 4: YOUR FUTURE WITH EVERY with Sprite Lemon-Lime Block Reveal */}
        <BlockTextReveal
          progress={scrollYProgress}
          range={[0.52, 0.74]}
          blockColor="#D8FA00"
          className="w-full"
        >
          <h2
            className="w-full font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white"
            style={{
              textShadow: '0px 3px 8px rgba(0, 0, 0, 0.18), 0px 10px 28px rgba(0, 0, 0, 0.12)',
            }}
          >
            YOUR FUTURE WITH EVERY
          </h2>
        </BlockTextReveal>

        {/* LINE 5: GULP OF PERFECT CAFFEINE with White/Citrus Block Reveal */}
        <BlockTextReveal
          progress={scrollYProgress}
          range={[0.68, 0.90]}
          blockColor="#FFFFFF"
          className="w-full mt-1 sm:mt-2"
        >
          <h2
            className="w-full font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white"
            style={{
              textShadow: '0px 3px 8px rgba(0, 0, 0, 0.18), 0px 10px 28px rgba(0, 0, 0, 0.12)',
            }}
          >
            GULP OF PERFECT CAFFEINE
          </h2>
        </BlockTextReveal>
      </motion.div>
    </section>
  );
};
