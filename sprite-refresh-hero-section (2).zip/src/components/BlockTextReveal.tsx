import React from 'react';
import { motion, MotionValue, useTransform } from 'motion/react';

interface BlockTextRevealProps {
  children: React.ReactNode;
  progress?: MotionValue<number>;
  range?: [number, number];
  blockColor?: string; // e.g., '#D8FA00' (Sprite Lemon-Lime) or '#008A44'
  className?: string;
  delay?: number;
  direction?: 'left-to-right' | 'right-to-left';
}

export const BlockTextReveal: React.FC<BlockTextRevealProps> = ({
  children,
  progress,
  range = [0.1, 0.4],
  blockColor = '#D8FA00',
  className = '',
  delay = 0,
  direction = 'left-to-right',
}) => {
  // If progress is provided (scroll-driven mode)
  if (progress) {
    const start = range[0];
    const end = range[1];
    const mid = start + (end - start) * 0.48;

    // Block enters [start -> mid] expanding scaleX 0 to 1, origin left
    // Block exits [mid -> end] collapsing scaleX 1 to 0, origin right
    // Text opacity transitions from 0 to 1 right around mid
    const textOpacity = useTransform(progress, [mid - 0.04, mid], [0.3, 1]);
    const textScale = useTransform(progress, [mid, end], [0.98, 1]);
    const textY = useTransform(progress, [mid, end], [6, 0]);

    // Block wipe transformation
    const blockScaleX = useTransform(
      progress,
      [start, mid, mid + 0.02, end],
      [0, 1, 1, 0]
    );

    const blockOrigin = useTransform(progress, (val: number) => {
      return val < mid ? (direction === 'left-to-right' ? '0% 50%' : '100% 50%') : (direction === 'left-to-right' ? '100% 50%' : '0% 50%');
    });

    return (
      <div className={`relative inline-block overflow-hidden my-0.5 ${className}`}>
        {/* Dynamic Wipe Block */}
        <motion.div
          style={{
            scaleX: blockScaleX,
            transformOrigin: blockOrigin,
            backgroundColor: blockColor,
          }}
          className="absolute inset-0 z-20 pointer-events-none rounded-sm shadow-[0_2px_12px_rgba(216,250,0,0.35)]"
        />

        {/* Revealed Text Content */}
        <motion.div
          style={{
            opacity: textOpacity,
            scale: textScale,
            y: textY,
          }}
          className="relative z-10"
        >
          {children}
        </motion.div>
      </div>
    );
  }

  // Viewport in-view trigger mode (standalone block reveal)
  return (
    <div className={`relative inline-block overflow-hidden my-0.5 ${className}`}>
      {/* Sliding Block */}
      <motion.div
        initial={{ scaleX: 0, transformOrigin: '0% 50%' }}
        whileInView={{
          scaleX: [0, 1, 1, 0],
          transformOrigin: ['0% 50%', '0% 50%', '100% 50%', '100% 50%'],
        }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{
          duration: 0.9,
          delay,
          ease: [0.77, 0, 0.175, 1],
          times: [0, 0.45, 0.55, 1],
        }}
        style={{ backgroundColor: blockColor }}
        className="absolute inset-0 z-20 pointer-events-none rounded-sm shadow-[0_2px_12px_rgba(216,250,0,0.35)]"
      />

      {/* Unveiled Typography */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{
          duration: 0.5,
          delay: delay + 0.45,
          ease: [0.19, 1, 0.22, 1],
        }}
        className="relative z-10"
      >
        {children}
      </motion.div>
    </div>
  );
};
