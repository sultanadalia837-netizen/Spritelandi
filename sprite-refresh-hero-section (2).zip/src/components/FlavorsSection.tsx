import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { spriteAudio } from '../utils/audio';

const FLAVORS_BG_IMAGE = 'https://res.cloudinary.com/nhkvpmhr/image/upload/v1787996814/IMG-20260829-WA0019.jpg';
const SKY_CLOUD_MASK_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787815925/file_00000000d2848211a74f06c8f2a75677_vyxyww.png';

const FLAVORS = [
  {
    id: 'original',
    name: 'ORIGINAL LEMON-LIME',
    shortName: 'ORIGINAL',
    tag: '01',
    accentColor: '#D8FA00',
    image: 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753604/file_00000000689081fdba99b19e7dbc6094_hf8odj.png',
    alt: 'Original Sprite Lemon-Lime Can on Island',
  },
  {
    id: 'strawberry',
    name: 'STRAWBERRY SPLASH',
    shortName: 'STRAWBERRY',
    tag: '02',
    accentColor: '#FF4D6D',
    image: 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787904550/file_0000000094d4821184283e00ba43d802_qa9fxr.png',
    alt: 'Strawberry Flavor Sprite Can on Island',
  },
  {
    id: 'tropical',
    name: 'TROPICAL HEATWAVE',
    shortName: 'TROPICAL',
    tag: '03',
    accentColor: '#FFAA00',
    image: 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787799318/file_00000000db2882098893b24b1616b047_uw6bka.png',
    alt: 'Tropical Orange Flavor Sprite Can on Island',
  },
];

export const FlavorsSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeFlavorIndex, setActiveFlavorIndex] = useState<number>(0);

  // Parallax scroll scrub linked to viewport progress
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  // 1. Background layer 3D depth parallax
  const bgY = useTransform(scrollYProgress, [0, 1], [-60, 60]);
  const bgScale = useTransform(scrollYProgress, [0, 0.5, 1], [1.06, 1.02, 1.06]);

  // 2. Desktop Individual Typography Cinematic Scroll Transforms
  const weY = useTransform(scrollYProgress, [0.08, 0.45], [40, -18]);
  const weX = useTransform(scrollYProgress, [0.08, 0.45], [-20, 0]);
  const weOpacity = useTransform(scrollYProgress, [0.08, 0.28], [0.2, 1]);
  const weScale = useTransform(scrollYProgress, [0.08, 0.32], [0.88, 1]);

  const haveY = useTransform(scrollYProgress, [0.12, 0.5], [50, -22]);
  const haveX = useTransform(scrollYProgress, [0.12, 0.5], [25, 0]);
  const haveOpacity = useTransform(scrollYProgress, [0.12, 0.34], [0.2, 1]);
  const haveScale = useTransform(scrollYProgress, [0.12, 0.38], [0.88, 1]);

  const numY = useTransform(scrollYProgress, [0.18, 0.56], [65, -28]);
  const numX = useTransform(scrollYProgress, [0.18, 0.56], [-30, 0]);
  const numOpacity = useTransform(scrollYProgress, [0.16, 0.42], [0.2, 1]);
  const numScale = useTransform(scrollYProgress, [0.16, 0.46], [0.85, 1]);

  const flavorsY = useTransform(scrollYProgress, [0.22, 0.62], [75, -32]);
  const flavorsX = useTransform(scrollYProgress, [0.22, 0.62], [35, 0]);
  const flavorsOpacity = useTransform(scrollYProgress, [0.2, 0.48], [0.2, 1]);
  const flavorsScale = useTransform(scrollYProgress, [0.2, 0.52], [0.86, 1]);

  // Can container parallax float
  const canBaseParallaxY = useTransform(scrollYProgress, [0, 1], [40, -40]);

  // Atmospheric Seam Cloud Mask Dynamic Scroll Shift & Parallax
  const cloudMaskY = useTransform(scrollYProgress, [0, 0.5, 1], [-30, 0, 35]);
  const cloudMaskScale = useTransform(scrollYProgress, [0, 0.5, 1], [1.04, 1.0, 0.98]);

  // Mobile Scroll-Linked Transforms
  const mobileTopTextY = useTransform(scrollYProgress, [0.08, 0.42], [30, -10]);
  const mobileTopTextOpacity = useTransform(scrollYProgress, [0.06, 0.28], [0.2, 1]);
  const mobileTopTextScale = useTransform(scrollYProgress, [0.06, 0.3], [0.9, 1]);

  const mobileBottomTextY = useTransform(scrollYProgress, [0.15, 0.5], [40, -15]);
  const mobileBottomTextOpacity = useTransform(scrollYProgress, [0.12, 0.38], [0.2, 1]);
  const mobileBottomTextScale = useTransform(scrollYProgress, [0.12, 0.4], [0.9, 1]);

  const handleSelectFlavor = (index: number) => {
    if (index !== activeFlavorIndex) {
      spriteAudio.playCanPop();
      setActiveFlavorIndex(index);
    }
  };

  // Helper to determine placement for each flavor
  const getFlavorSlot = (index: number) => {
    if (index === activeFlavorIndex) return 'center';
    // If active is 0: 1 is left, 2 is right
    // If active is 1: 0 is left, 2 is right
    // If active is 2: 1 is left, 0 is right
    if (activeFlavorIndex === 0) {
      return index === 1 ? 'left' : 'right';
    } else if (activeFlavorIndex === 1) {
      return index === 0 ? 'left' : 'right';
    } else {
      return index === 1 ? 'left' : 'right';
    }
  };

  return (
    <section
      ref={sectionRef}
      id="flavors"
      className="relative w-full bg-[#62b9f3] flex flex-col items-center justify-center select-none overflow-visible z-20"
    >
      {/* 
        0. ATMOSPHERIC SKY / CLOUD MASK (SEAM BETWEEN ABOUT & FLAVORS SECTION)
        Reduced vertical reach by 20px so it does not cover the main text ("WE"), positioned cleanly over the seam with 100% opacity.
      */}
      <motion.div
        style={{
          y: cloudMaskY,
          scale: cloudMaskScale,
          filter: 'blur(2px)',
          opacity: 1,
        }}
        className="absolute -top-7 md:-top-5 left-1/2 -translate-x-1/2 -translate-y-[50%] w-[215%] xs:w-[190%] sm:w-[165%] md:w-[145%] lg:w-[140%] max-w-[2200px] pointer-events-none z-50 overflow-visible flex items-center justify-center"
      >
        <img
          src={SKY_CLOUD_MASK_IMG}
          alt="Atmospheric Clouds Separation Mask"
          className="w-full h-auto max-h-none object-contain pointer-events-none select-none scale-110"
          crossOrigin="anonymous"
          loading="eager"
        />
      </motion.div>

      {/* Soft bottom blending gradient for Flavors section */}
      <div
        className="absolute bottom-0 left-0 right-0 h-28 sm:h-36 md:h-44 pointer-events-none z-20"
        style={{
          background:
            'linear-gradient(to top, rgba(98, 185, 243, 0.95) 0%, rgba(98, 185, 243, 0.4) 50%, rgba(98, 185, 243, 0) 100%)',
        }}
      />

      {/* Shared SVG Definitions */}
      <svg className="absolute w-0 h-0 pointer-events-none" aria-hidden="true">
        <defs>
          <linearGradient id="flavorTextGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#EBFFC5" stopOpacity="1" />
            <stop offset="100%" stopColor="#FDFFF9" stopOpacity="1" />
          </linearGradient>
          <filter id="softTextShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="6" stdDeviation="5" floodColor="#000000" floodOpacity="0.2" />
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#000000" floodOpacity="0.15" />
          </filter>
          <filter id="mobileTextShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="3" floodColor="#000000" floodOpacity="0.25" />
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#000000" floodOpacity="0.2" />
          </filter>
        </defs>
      </svg>

      {/* 
        ========================================================================
        A. DESKTOP & TABLET VIEWPORT (md:block)
        Matches exact reference design canvas: 1448 x 1086 px ratio with 3D Parallax
        ========================================================================
      */}
      <div className="hidden md:block relative w-full max-w-[1448px] aspect-[1448/1086] overflow-hidden">
        {/* Layer 1: Parallax Background Image */}
        <motion.div
          style={{ y: bgY, scale: bgScale }}
          className="absolute inset-[-6%] w-[112%] h-[112%] pointer-events-none z-0"
        >
          <img
            src={FLAVORS_BG_IMAGE}
            alt="Flavors Landscape Background"
            className="w-full h-full object-cover pointer-events-none"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Layer 2: Typography Layer with Individual Dynamic Scroll Animations */}
        <div className="absolute inset-0 z-10 pointer-events-none">
          {/* THE WORD "WE" */}
          <motion.div
            style={{
              left: `${(282.5 / 1448) * 100}%`,
              top: `${(121 / 1086) * 100}%`,
              width: `${(374.4 / 1448) * 100}%`,
              height: `${(309.2 / 1086) * 100}%`,
              y: weY,
              x: weX,
              opacity: weOpacity,
              scale: weScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 374.4 309.2" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="245"
                fontFamily="'Lilita One', sans-serif"
                fontSize="290"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="374.4"
                lengthAdjust="spacingAndGlyphs"
              >
                WE
              </text>
            </svg>
          </motion.div>

          {/* THE WORD "HAVE" */}
          <motion.div
            style={{
              left: `${(675 / 1448) * 100}%`,
              top: `${(143.4 / 1086) * 100}%`,
              width: `${(542.6 / 1448) * 100}%`,
              height: `${(269.4 / 1086) * 100}%`,
              y: haveY,
              x: haveX,
              opacity: haveOpacity,
              scale: haveScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 542.6 269.4" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="225"
                fontFamily="'Lilita One', sans-serif"
                fontSize="260"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="542.6"
                lengthAdjust="spacingAndGlyphs"
              >
                HAVE
              </text>
            </svg>
          </motion.div>

          {/* THE NUMBER "03" */}
          <motion.div
            style={{
              left: `${(117.9 / 1448) * 100}%`,
              top: `${(318.6 / 1086) * 100}%`,
              width: `${(419 / 1448) * 100}%`,
              height: `${(428.8 / 1086) * 100}%`,
              y: numY,
              x: numX,
              opacity: numOpacity,
              scale: numScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 419 428.8" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="350"
                fontFamily="'Lilita One', sans-serif"
                fontSize="410"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="8"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="419"
                lengthAdjust="spacingAndGlyphs"
              >
                03
              </text>
            </svg>
          </motion.div>

          {/* THE WORD "FLAVORS" */}
          <motion.div
            style={{
              left: `${(549.9 / 1448) * 100}%`,
              top: `${(384.1 / 1086) * 100}%`,
              width: `${(853.8 / 1448) * 100}%`,
              height: `${(255.7 / 1086) * 100}%`,
              y: flavorsY,
              x: flavorsX,
              opacity: flavorsOpacity,
              scale: flavorsScale,
            }}
            className="absolute"
          >
            <svg viewBox="0 0 853.8 255.7" className="w-full h-full overflow-visible">
              <text
                x="0"
                y="215"
                fontFamily="'Lilita One', sans-serif"
                fontSize="250"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="6"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#softTextShadow)"
                textLength="853.8"
                lengthAdjust="spacingAndGlyphs"
              >
                FLAVORS
              </text>
            </svg>
          </motion.div>
        </div>

        {/* 
          Layer 3: Interactive Product Cans Layer (Zero Rotation - All Islands Straight!)
          Clicking any flavor smoothly brings it to the front center, moving others back to the sides.
        */}
        <motion.div style={{ y: canBaseParallaxY }} className="absolute inset-0 z-20 pointer-events-auto">
          {FLAVORS.map((flavor, index) => {
            const slot = getFlavorSlot(index);
            const isCenter = slot === 'center';
            const isLeft = slot === 'left';

            // Coordinates for Desktop:
            // Center foreground: centered around x: 50%, y: 52%, width: 1011px, scale: 1, zIndex: 30
            // Left background: x: 10%, y: 56%, width: 440px, scale: 0.76, zIndex: 15
            // Right background: x: 90%, y: 56%, width: 440px, scale: 0.76, zIndex: 15
            let targetX = '50%';
            let targetY = '56%';
            let targetScale = 1.0;
            let targetZIndex = 30;
            let targetBlur = '0px';
            let targetOpacity = 1.0;

            if (isLeft) {
              targetX = '12%';
              targetY = '62%';
              targetScale = 0.52;
              targetZIndex = 15;
              targetBlur = '1.8px';
              targetOpacity = 0.88;
            } else if (!isCenter) {
              // Right
              targetX = '88%';
              targetY = '62%';
              targetScale = 0.52;
              targetZIndex = 15;
              targetBlur = '1.8px';
              targetOpacity = 0.88;
            }

            return (
              <motion.div
                key={flavor.id}
                onClick={() => handleSelectFlavor(index)}
                initial={false}
                animate={{
                  left: targetX,
                  top: targetY,
                  scale: targetScale,
                  zIndex: targetZIndex,
                  filter: `blur(${targetBlur})`,
                  opacity: targetOpacity,
                }}
                whileHover={
                  !isCenter
                    ? {
                        scale: targetScale * 1.06,
                        opacity: 1,
                        filter: 'blur(0px)',
                      }
                    : undefined
                }
                transition={{
                  type: 'spring',
                  stiffness: 240,
                  damping: 28,
                  mass: 0.9,
                }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 w-[1011px] h-[674px] flex items-center justify-center ${
                  isCenter ? 'cursor-default' : 'cursor-pointer'
                }`}
                style={{
                  rotate: 0, // STRICTLY STRAIGHT - ZERO ROTATION ON ALL ISLANDS
                }}
              >
                <img
                  src={flavor.image}
                  alt={flavor.alt}
                  className={`w-full h-full object-contain pointer-events-none select-none ${
                    isCenter
                      ? 'drop-shadow-[0_20px_30px_rgba(0,0,0,0.42)] drop-shadow-[0_4px_10px_rgba(0,0,0,0.25)]'
                      : 'drop-shadow-[0_12px_20px_rgba(0,0,0,0.3)]'
                  }`}
                  crossOrigin="anonymous"
                  loading="eager"
                  style={{
                    transform: 'rotate(0deg)', // Ensure straight orientation
                  }}
                />

                {/* Clickable Hover Badge on Side Cans */}
                {!isCenter && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    whileHover={{ opacity: 1, y: 0 }}
                    className="absolute bottom-[20%] px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/40 text-white font-lilita text-sm tracking-wider uppercase shadow-lg pointer-events-none"
                  >
                    Click to view {flavor.shortName}
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </motion.div>

        {/* Layer 4: Interactive Flavor Selector Control Pill (Desktop) */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-40 flex items-center gap-2 p-1.5 rounded-full bg-white/20 backdrop-blur-xl border border-white/40 shadow-[0_8px_32px_rgba(0,0,0,0.18)]">
          {FLAVORS.map((flavor, index) => {
            const isSelected = index === activeFlavorIndex;
            return (
              <button
                key={flavor.id}
                onClick={() => handleSelectFlavor(index)}
                className={`relative px-5 py-2 rounded-full font-lilita text-sm tracking-wider transition-all duration-300 flex items-center gap-2 ${
                  isSelected
                    ? 'text-[#003816] shadow-[0_2px_10px_rgba(216,250,0,0.4)]'
                    : 'text-white hover:text-white/90 hover:bg-white/10'
                }`}
              >
                {isSelected && (
                  <motion.div
                    layoutId="activeFlavorPillDesktop"
                    className="absolute inset-0 rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E9FF47] to-[#D8FA00]"
                    transition={{ type: 'spring', stiffness: 320, damping: 30 }}
                  />
                )}
                <span className="relative z-10 opacity-75 font-mono text-xs">{flavor.tag}</span>
                <span className="relative z-10">{flavor.shortName}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 
        ========================================================================
        B. MOBILE VIEWPORT (block md:hidden)
        100% Responsive with Interactive Flavor Switching & Zero Island Rotation
        ========================================================================
      */}
      <div className="block md:hidden relative w-full min-h-[580px] xs:min-h-[640px] sm:min-h-[700px] overflow-hidden flex flex-col items-center justify-between pb-8">
        {/* Parallax Background Image */}
        <motion.div
          style={{ y: bgY, scale: bgScale }}
          className="absolute inset-[-8%] w-[116%] h-[116%] pointer-events-none z-0"
        >
          <img
            src={FLAVORS_BG_IMAGE}
            alt="Flavors Landscape Background"
            className="w-full h-full object-cover object-center pointer-events-none"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Mobile Typography Layer */}
        <div className="relative z-10 w-full pt-12 xs:pt-14 sm:pt-20 px-4 flex flex-col items-center pointer-events-none">
          {/* Top Line: WE HAVE */}
          <motion.div
            style={{
              y: mobileTopTextY,
              opacity: mobileTopTextOpacity,
              scale: mobileTopTextScale,
            }}
            className="w-full max-w-[360px] flex items-center justify-center"
          >
            <svg viewBox="0 0 540 140" className="w-[85%] max-w-[320px] h-auto overflow-visible">
              <text
                x="50%"
                y="110"
                textAnchor="middle"
                fontFamily="'Lilita One', sans-serif"
                fontSize="120"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="5"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#mobileTextShadow)"
                letterSpacing="4"
              >
                WE HAVE
              </text>
            </svg>
          </motion.div>

          {/* Bottom Line: 03 FLAVORS */}
          <motion.div
            style={{
              y: mobileBottomTextY,
              opacity: mobileBottomTextOpacity,
              scale: mobileBottomTextScale,
            }}
            className="w-full max-w-[420px] flex items-center justify-center -mt-2 xs:-mt-1"
          >
            <svg viewBox="0 0 660 150" className="w-[95%] max-w-[380px] h-auto overflow-visible">
              <text
                x="50%"
                y="120"
                textAnchor="middle"
                fontFamily="'Lilita One', sans-serif"
                fontSize="130"
                fill="url(#flavorTextGrad)"
                stroke="#FFFFFF"
                strokeWidth="5.5"
                strokeLinejoin="round"
                style={{ paintOrder: 'stroke fill' }}
                filter="url(#mobileTextShadow)"
                letterSpacing="2"
              >
                03 FLAVORS
              </text>
            </svg>
          </motion.div>
        </div>

        {/* Mobile Interactive Product Cans Composition (Strictly Straight - 0deg) */}
        <div className="relative w-full h-[320px] xs:h-[360px] sm:h-[400px] mt-2 z-20 flex items-center justify-center pointer-events-auto">
          {FLAVORS.map((flavor, index) => {
            const slot = getFlavorSlot(index);
            const isCenter = slot === 'center';
            const isLeft = slot === 'left';

            let mobileLeft = '50%';
            let mobileScale = 1.0;
            let mobileZIndex = 30;
            let mobileBlur = '0px';
            let mobileOpacity = 1.0;

            if (isLeft) {
              mobileLeft = '8%';
              mobileScale = 0.52;
              mobileZIndex = 15;
              mobileBlur = '1.5px';
              mobileOpacity = 0.85;
            } else if (!isCenter) {
              // Right
              mobileLeft = '92%';
              mobileScale = 0.52;
              mobileZIndex = 15;
              mobileBlur = '1.5px';
              mobileOpacity = 0.85;
            }

            return (
              <motion.div
                key={`mobile-${flavor.id}`}
                onClick={() => handleSelectFlavor(index)}
                initial={false}
                animate={{
                  left: mobileLeft,
                  scale: mobileScale,
                  zIndex: mobileZIndex,
                  filter: `blur(${mobileBlur})`,
                  opacity: mobileOpacity,
                }}
                transition={{
                  type: 'spring',
                  stiffness: 240,
                  damping: 28,
                }}
                className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-[85%] max-w-[380px] aspect-[3/2] flex items-center justify-center ${
                  isCenter ? 'cursor-default' : 'cursor-pointer active:scale-95'
                }`}
                style={{
                  rotate: 0, // ALL ISLANDS STRICTLY STRAIGHT - ZERO ROTATION
                }}
              >
                <img
                  src={flavor.image}
                  alt={flavor.alt}
                  className={`w-full h-full object-contain pointer-events-none select-none ${
                    isCenter
                      ? 'drop-shadow-[0_16px_22px_rgba(0,0,0,0.38)] drop-shadow-[0_4px_8px_rgba(0,0,0,0.2)]'
                      : 'drop-shadow-[0_8px_14px_rgba(0,0,0,0.25)]'
                  }`}
                  crossOrigin="anonymous"
                  loading="eager"
                  style={{
                    transform: 'rotate(0deg)', // Unrotated straight orientation
                  }}
                />
              </motion.div>
            );
          })}
        </div>

        {/* Mobile Flavor Selector Control Tabs */}
        <div className="relative z-30 w-full px-4 flex items-center justify-center mt-2">
          <div className="flex items-center gap-1.5 p-1 rounded-full bg-white/20 backdrop-blur-lg border border-white/35 shadow-md">
            {FLAVORS.map((flavor, index) => {
              const isSelected = index === activeFlavorIndex;
              return (
                <button
                  key={`btn-mob-${flavor.id}`}
                  onClick={() => handleSelectFlavor(index)}
                  className={`relative px-3.5 py-1.5 rounded-full font-lilita text-xs tracking-wider transition-all duration-300 ${
                    isSelected ? 'text-[#003816]' : 'text-white/90 hover:text-white'
                  }`}
                >
                  {isSelected && (
                    <motion.div
                      layoutId="activeFlavorPillMobile"
                      className="absolute inset-0 rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E9FF47] to-[#D8FA00] shadow-sm"
                      transition={{ type: 'spring', stiffness: 320, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{flavor.shortName}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
