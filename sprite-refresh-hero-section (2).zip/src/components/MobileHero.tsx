import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { MobileNavbar } from './MobileNavbar';
import { SpriteInteractiveCTA } from './SpriteInteractiveCTA';
import { BubbleAtmosphere } from './BubbleAtmosphere';
import { ProductSpotlightReveal } from './ProductSpotlightReveal';

const BACKGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753603/1_20260826_200445_0000_u7lbnw.png';
const FOREGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753604/file_00000000689081fdba99b19e7dbc6094_hf8odj.png';
const REVEAL_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787799318/file_00000000db2882098893b24b1616b047_uw6bka.png';
const SKY_CLOUD_MASK_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787815925/file_00000000d2848211a74f06c8f2a75677_vyxyww.png';

interface MobileHeroProps {
  revealTrigger?: number;
}

export const MobileHero: React.FC<MobileHeroProps> = ({ revealTrigger = 0 }) => {
  const [isEntranceComplete, setIsEntranceComplete] = useState<boolean>(false);

  useEffect(() => {
    setIsEntranceComplete(false);
    const timer = setTimeout(() => {
      setIsEntranceComplete(true);
    }, 1800);
    return () => clearTimeout(timer);
  }, [revealTrigger]);

  const headlineLetters = ['R', 'E', 'F', 'R', 'E', 'S', 'H'];

  return (
    <div
      id="sprite-mobile-hero"
      className="relative w-full min-h-screen h-[100dvh] overflow-visible bg-[#6db2ea] flex flex-col justify-between select-none"
    >
      {/* 1. Dynamic Scenic Background with Silky Zoom & Ambient Glow */}
      <motion.div
        key={`mobile-bg-${revealTrigger}`}
        initial={{ scale: 1.1, opacity: 0.8 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.8, ease: [0.19, 1, 0.22, 1] }}
        className="absolute inset-0 w-full h-full z-0 overflow-hidden"
      >
        <img
          src={BACKGROUND_IMG}
          alt="Scenic Sprite Sky Background"
          className="w-full h-full object-cover object-center pointer-events-none"
          crossOrigin="anonymous"
          loading="eager"
        />

        {/* Ambient Soft White Light Bloom behind product */}
        <motion.div
          key={`mobile-sunburst-${revealTrigger}`}
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: [0.5, 1.2, 1], opacity: [0, 0.5, 0.3] }}
          transition={{ duration: 2.0, ease: [0.19, 1, 0.22, 1] }}
          className="absolute left-1/2 top-[48%] -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] rounded-full pointer-events-none"
          style={{
            background:
              'radial-gradient(circle, rgba(255,255,255,0.45) 0%, rgba(255,248,220,0.2) 35%, rgba(255,255,255,0) 70%)',
          }}
        />
      </motion.div>

      {/* Atmospheric Fizzing Bubbles */}
      <BubbleAtmosphere />

      {/* 2. Mobile Frosted Glass Navbar */}
      <MobileNavbar revealTrigger={revealTrigger} />

      {/* 3. Main Mobile Interactive Content Area */}
      <div className="relative z-10 w-full flex-1 flex flex-col items-center justify-center px-4 pt-20 sm:pt-22 pb-4 landscape:pt-11 landscape:pb-1">
        {/* Main 3D Headline "REFRESH" - Shifted down for balanced visual hierarchy */}
        <div className="w-full text-center pointer-events-none mt-2 sm:mt-3 mb-0 sm:mb-1 landscape:mt-0 landscape:-mb-1">
          <h1
            className="font-lilita flex items-center justify-center leading-none select-none tracking-[-0.04em] text-[clamp(52px,16vw,96px)] landscape:text-[clamp(30px,6.5vw,44px)]"
          >
            {headlineLetters.map((char, index) => (
              <span
                key={`${char}-${index}-${revealTrigger}`}
                className="inline-block overflow-hidden pb-2 landscape:pb-0.5"
                style={{ perspective: '600px' }}
              >
                <motion.span
                  className="inline-block text-headline-3d"
                  initial={{
                    y: 120,
                    opacity: 0,
                    rotateX: 45,
                    filter: 'blur(8px)',
                  }}
                  animate={{
                    y: 0,
                    opacity: 1,
                    rotateX: 0,
                    filter: 'blur(0px)',
                  }}
                  transition={{
                    duration: 1.2,
                    delay: 0.15 + index * 0.05,
                    ease: [0.19, 1, 0.22, 1],
                  }}
                >
                  {char}
                </motion.span>
              </span>
            ))}
          </h1>
        </div>

        {/* Floating Sprite Can & Grass Island with Flanking Sub-Headlines */}
        <div className="relative w-full max-w-[380px] aspect-[4/3] landscape:max-w-[240px] landscape:aspect-[16/10] landscape:max-h-[140px] flex items-center justify-center my-auto landscape:my-0.5">
          {/* Sub-headline "YOUR" (Left) */}
          <motion.div
            key={`mobile-your-${revealTrigger}`}
            initial={{ opacity: 0, x: -40, rotate: -8, filter: 'blur(6px)' }}
            animate={{ opacity: 1, x: 0, rotate: 0, filter: 'blur(0px)' }}
            transition={{ duration: 1.2, delay: 0.45, ease: [0.19, 1, 0.22, 1] }}
            className="absolute left-1 landscape:left-0 top-[28%] z-10 pointer-events-none"
          >
            <span
              className="font-lilita text-subheadline-3d leading-none text-[clamp(24px,7vw,38px)] landscape:text-[clamp(16px,3.2vw,22px)]"
            >
              YOUR
            </span>
          </motion.div>

          {/* Sub-headline "WORLD" (Right) */}
          <motion.div
            key={`mobile-world-${revealTrigger}`}
            initial={{ opacity: 0, x: 40, rotate: 8, filter: 'blur(6px)' }}
            animate={{ opacity: 1, x: 0, rotate: 0, filter: 'blur(0px)' }}
            transition={{ duration: 1.2, delay: 0.52, ease: [0.19, 1, 0.22, 1] }}
            className="absolute right-1 landscape:right-0 top-[28%] z-10 pointer-events-none"
          >
            <span
              className="font-lilita text-subheadline-3d leading-none text-[clamp(24px,7vw,38px)] landscape:text-[clamp(16px,3.2vw,22px)]"
            >
              WORLD
            </span>
          </motion.div>

          {/* Sprite Can & Island - Touch/Cursor Spotlight Reveal */}
          <div
            className="relative w-full h-full z-20 flex items-center justify-center pointer-events-auto"
          >
            <ProductSpotlightReveal
              baseImage={FOREGROUND_IMG}
              revealImage={REVEAL_IMG}
              alt="Sprite Can on Moss Island"
              spotlightRadius={130}
            />
          </div>
        </div>

        {/* Interactive Dual-Shape CTA Button */}
        <motion.div
          key={`mobile-cta-${revealTrigger}`}
          initial={{ opacity: 0, y: 35, scale: 0.88 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.0, delay: 0.65, ease: [0.34, 1.4, 0.64, 1] }}
          className="relative z-30 mt-1 mb-2 landscape:mt-0 landscape:mb-1 landscape:scale-80 origin-center flex items-center justify-center"
        >
          <SpriteInteractiveCTA
            onExplore={() => {
              const aboutEl = document.getElementById('about');
              aboutEl?.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        </motion.div>
      </div>

      {/* 
        Clouds Mask Layer placed at the absolute bottom of the first section (spanning between Hero and 2nd section) 
        Top-most z-[90], increased size (420px height, 215% width), shifted 40px top (-bottom-[95px] / landscape:-bottom-[165px]), 100% opacity.
      */}
      <motion.div
        key={`mobile-clouds-mask-${revealTrigger}`}
        initial={{ opacity: 0, y: 15, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 1.4, delay: 0.3, ease: [0.19, 1, 0.22, 1] }}
        className="absolute left-1/2 -translate-x-1/2 w-[215%] sm:w-[175%] h-[420px] pointer-events-none z-[90] -bottom-[95px] landscape:-bottom-[165px]"
        style={{
          filter: 'blur(2px)',
          opacity: 1,
        }}
      >
        <img
          src={SKY_CLOUD_MASK_IMG}
          alt="Cloud Masking Layer"
          className="w-full h-full object-contain object-bottom scale-130"
          crossOrigin="anonymous"
          loading="eager"
        />
      </motion.div>

      {/* Smooth bottom edge blending gradient into About section sky */}
      <div
        className="absolute bottom-0 left-0 right-0 h-28 sm:h-36 pointer-events-none z-15"
        style={{
          background: 'linear-gradient(to top, rgba(109, 178, 234, 0.9) 0%, rgba(109, 178, 234, 0.45) 50%, rgba(109, 178, 234, 0) 100%)',
        }}
      />

      {/* 4. Mobile Footer with Staggered Social Icons */}
      <footer className="relative z-20 w-full px-5 py-3.5 landscape:py-1.5 landscape:px-4 flex items-center justify-between bg-black/10 backdrop-blur-sm border-t border-white/20">
        {/* Social Icons with authentic, professional vector logos */}
        <div className="flex items-center gap-2">
          <motion.a
            key={`mobile-ig-${revealTrigger}`}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8, ease: [0.34, 1.56, 0.64, 1] }}
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            className="w-8 h-8 rounded-full border border-white/30 bg-white/15 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/25 active:scale-90 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.12)]"
          >
            {/* Authentic, precision-engineered Instagram camera glyph */}
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2.5" y="2.5" width="19" height="19" rx="5.2" ry="5.2" />
              <circle cx="12" cy="12" r="4.2" />
              <circle cx="17.6" cy="6.4" r="1.1" fill="currentColor" />
            </svg>
          </motion.a>
          <motion.a
            key={`mobile-tt-${revealTrigger}`}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.88, ease: [0.34, 1.56, 0.64, 1] }}
            href="https://tiktok.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="TikTok"
            className="w-8 h-8 rounded-full border border-white/30 bg-white/15 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/25 active:scale-90 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.12)]"
          >
            <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
              <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298 0 .592.046.87.136V9.4a6.33 6.33 0 0 0-.87-.06A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 10.74 4.54 6.28 6.28 0 0 0 1.94-4.57V8.58a8.28 8.28 0 0 0 4.84 1.56V6.69z" />
            </svg>
          </motion.a>
          <motion.a
            key={`mobile-fb-${revealTrigger}`}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.96, ease: [0.34, 1.56, 0.64, 1] }}
            href="https://facebook.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
            className="w-8 h-8 rounded-full border border-white/30 bg-white/15 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/25 active:scale-90 transition-all shadow-[0_2px_8px_rgba(0,0,0,0.12)]"
          >
            <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          </motion.a>
        </div>

        {/* Tagline */}
        <motion.p
          key={`mobile-tagline-${revealTrigger}`}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.85, ease: [0.19, 1, 0.22, 1] }}
          className="text-right text-white/80 font-montserrat text-[11px] leading-[1.3] font-medium"
        >
          Crisp citrus. Cold refresh.
        </motion.p>
      </footer>
    </div>
  );
};
