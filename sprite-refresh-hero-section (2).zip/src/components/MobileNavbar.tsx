import React from 'react';
import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface MobileNavbarProps {
  revealTrigger?: number;
}

export const MobileNavbar: React.FC<MobileNavbarProps> = ({ revealTrigger = 0 }) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-5 pt-4 pb-3 flex items-center justify-between w-full pointer-events-none">
      {/* Sprite Logo with Elastic Drop */}
      <motion.div
        key={`mob-logo-${revealTrigger}`}
        initial={{ y: -30, opacity: 0, scale: 0.9 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, delay: 0.1, ease: [0.19, 1, 0.22, 1] }}
        className="relative pointer-events-auto"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="transition-transform active:scale-95 duration-200 block cursor-pointer"
        >
          <SpriteLogo className="h-7" />
        </button>
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: [0, 1, 0], scale: [0.5, 1.3, 0.8] }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="absolute -top-1 -right-1.5 text-[#FFE500]"
        >
          <Sparkles className="w-3 h-3 fill-current" />
        </motion.div>
      </motion.div>

      {/* Professional Minimalist Stepped Hamburger Icon (Deactivated - No Drawer Opening) */}
      <motion.div
        key={`mob-menu-btn-${revealTrigger}`}
        initial={{ y: -30, opacity: 0, scale: 0.85 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, delay: 0.2, ease: [0.19, 1, 0.22, 1] }}
        className="pointer-events-auto"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
          }}
          type="button"
          aria-label="Navigation Menu (Inactive)"
          aria-disabled="true"
          className="relative w-10 h-10 rounded-full flex items-center justify-center bg-white/15 backdrop-blur-2xl border border-white/30 text-white shadow-[0_4px_16px_rgba(0,0,0,0.18)] active:scale-95 transition-all duration-200 cursor-default"
        >
          {/* Bespoke, luxury architectural stepped hamburger bars */}
          <svg
            className="w-[18px] h-[13px] text-white"
            viewBox="0 0 18 13"
            fill="none"
            stroke="currentColor"
          >
            <line x1="1" y1="1.5" x2="17" y2="1.5" strokeWidth="1.75" strokeLinecap="round" />
            <line x1="4.5" y1="6.5" x2="17" y2="6.5" strokeWidth="1.75" strokeLinecap="round" />
            <line x1="1" y1="11.5" x2="17" y2="11.5" strokeWidth="1.75" strokeLinecap="round" />
          </svg>
        </button>
      </motion.div>
    </header>
  );
};
