import React, { useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface NavbarProps {
  revealTrigger?: number;
}

export const Navbar: React.FC<NavbarProps> = ({ revealTrigger = 0 }) => {
  const [activeTab, setActiveTab] = useState<'Discover' | 'Flavors' | 'Refresh' | 'Explore'>('Discover');

  const navTabs: Array<'Discover' | 'Flavors' | 'Refresh' | 'Explore'> = [
    'Discover',
    'Flavors',
    'Refresh',
    'Explore',
  ];

  const handleTabClick = (tab: 'Discover' | 'Flavors' | 'Refresh' | 'Explore') => {
    setActiveTab(tab);
    spriteAudio.playButtonTap();
    if (tab === 'Flavors') {
      const el = document.getElementById('flavors');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'Refresh' || tab === 'Explore') {
      const aboutEl = document.getElementById('about');
      aboutEl?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="absolute top-0 left-0 right-0 z-30 px-12 pt-7 w-full grid grid-cols-[240px_1fr_240px] items-center">
      {/* 1. Brand Logo (Left - Aligned to start) with Elastic Drop & Lemon Gleam */}
      <motion.div
        key={`logo-${revealTrigger}`}
        initial={{ y: -45, opacity: 0, scale: 0.85 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{
          duration: 1.1,
          delay: 0.15,
          ease: [0.19, 1, 0.22, 1],
        }}
        className="flex items-center justify-start"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="relative group transition-transform hover:scale-105 active:scale-95 duration-200 cursor-pointer"
        >
          <SpriteLogo className="h-8 drop-shadow-[0_4px_12px_rgba(0,0,0,0.3)]" />
          {/* Subtle sparkling glint on reveal */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 0], scale: [0.5, 1.4, 0.8] }}
            transition={{ duration: 1.0, delay: 0.8, ease: 'easeOut' }}
            className="absolute -top-1 -right-1.5 text-[#FFE500]"
          >
            <Sparkles className="w-3.5 h-3.5 fill-current" />
          </motion.div>
        </button>
      </motion.div>

      {/* 2. Floating Center Navbar (Symmetrical Apple-style frosted glass pill) */}
      <div className="flex items-center justify-center">
        <motion.nav
          key={`nav-pill-${revealTrigger}`}
          initial={{ y: -35, opacity: 0, scale: 0.92 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          transition={{
            duration: 1.2,
            delay: 0.25,
            ease: [0.19, 1, 0.22, 1],
          }}
          className="flex items-center bg-white/[0.12] backdrop-blur-2xl border border-white/25 rounded-full p-1.5 transition-all duration-300 select-none"
          style={{
            boxShadow:
              '0 12px 36px 0 rgba(0, 0, 0, 0.22), 0 4px 12px 0 rgba(0, 0, 0, 0.12), inset 0 1px 1.5px 0 rgba(255, 255, 255, 0.45), inset 0 -1px 1px 0 rgba(0, 0, 0, 0.15)',
          }}
        >
          {navTabs.map((tab, idx) => {
            const isActive = activeTab === tab;
            return (
              <motion.button
                key={`${tab}-${revealTrigger}`}
                initial={{ y: -18, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{
                  duration: 0.8,
                  delay: 0.4 + idx * 0.08,
                  ease: [0.19, 1, 0.22, 1],
                }}
                onClick={() => handleTabClick(tab)}
                className={`relative px-6 py-2 rounded-full text-[15px] transition-all duration-200 font-montserrat flex flex-col items-center justify-center cursor-pointer ${
                  isActive
                    ? 'bg-white/30 text-white shadow-[0_2px_10px_rgba(0,0,0,0.18),inset_0_1px_1px_rgba(255,255,255,0.4)] font-semibold'
                    : 'text-white/85 hover:text-white hover:bg-white/15 font-medium'
                }`}
              >
                <span>{tab}</span>
                {tab === 'Refresh' && (
                  <span className="absolute -bottom-1 w-1.5 h-1.5 bg-[#65C435] rounded-full shadow-[0_0_10px_#65C435,0_0_4px_#FFE500]" />
                )}
              </motion.button>
            );
          })}
        </motion.nav>
      </div>

      {/* 3. Shop Sprite CTA (Right - Aligned to end) with kinetic slide-in */}
      <motion.div
        key={`shop-${revealTrigger}`}
        initial={{ x: 45, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{
          duration: 1.1,
          delay: 0.45,
          ease: [0.19, 1, 0.22, 1],
        }}
        className="flex items-center justify-end"
      >
        <button
          onClick={() => {
            spriteAudio.playCanPop();
            const aboutEl = document.getElementById('about');
            aboutEl?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="group flex items-center gap-2.5 text-white font-montserrat font-medium text-[15px] tracking-wide px-4 py-2 rounded-full hover:bg-white/15 active:scale-95 transition-all duration-200 cursor-pointer"
        >
          <span>Shop Sprite</span>
          <ArrowRight className="w-4 h-4 text-white group-hover:translate-x-1.5 transition-transform duration-200" />
        </button>
      </motion.div>
    </header>
  );
};
