import React, { useEffect, useRef, useState } from 'react';

interface ParticleTextProps {
  text?: string;
  className?: string;
  particleColor?: string;
  particleSize?: number;
  fontSize?: number;
  interactive?: boolean;
}

interface Particle {
  x: number;
  y: number;
  originX: number;
  originY: number;
  vx: number;
  vy: number;
  radius: number;
  baseRadius: number;
  color: string;
  alpha: number;
  friction: number;
  spring: number;
}

export const ParticleText: React.FC<ParticleTextProps> = ({
  text = 'SPRITE',
  className = '',
  particleSize = 2.4,
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    let width = 0;
    let height = 0;

    const mouse = {
      x: -1000,
      y: -1000,
      radius: 95,
      isActive: false,
    };

    const colorPalette = [
      '#FFFFFF',
      '#D8FA00', // Lemon lime yellow
      '#E9FF47',
      '#85D829', // Sprite electric lime
      '#A7E433',
    ];

    const initParticles = () => {
      if (!container || !canvas) return;
      const rect = container.getBoundingClientRect();
      width = rect.width;
      height = rect.height;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      // Create offscreen buffer to sample font text pixels
      const offscreen = document.createElement('canvas');
      const offCtx = offscreen.getContext('2d');
      if (!offCtx) return;

      offscreen.width = width;
      offscreen.height = height;

      // Calculate dynamic font size based on container width
      const calculatedFontSize = Math.min(Math.floor(width * 0.22), Math.floor(height * 0.75));
      offCtx.font = `900 ${calculatedFontSize}px 'Lilita One', Montserrat, sans-serif`;
      offCtx.textAlign = 'center';
      offCtx.textBaseline = 'middle';
      offCtx.fillStyle = '#FFFFFF';
      offCtx.fillText(text, width / 2, height / 2 + calculatedFontSize * 0.05);

      const imgData = offCtx.getImageData(0, 0, width, height);
      const data = imgData.data;
      particles = [];

      // Grid sampling step
      const step = Math.max(3, Math.floor(calculatedFontSize / 26));

      for (let y = 0; y < height; y += step) {
        for (let x = 0; x < width; x += step) {
          const index = (y * width + x) * 4;
          const alpha = data[index + 3];

          if (alpha > 128) {
            const color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
            const baseRad = (Math.random() * 0.8 + 0.6) * particleSize;
            particles.push({
              x: x + (Math.random() - 0.5) * 40,
              y: y + (Math.random() - 0.5) * 40,
              originX: x,
              originY: y,
              vx: (Math.random() - 0.5) * 2,
              vy: (Math.random() - 0.5) * 2,
              radius: baseRad,
              baseRadius: baseRad,
              color,
              alpha: Math.random() * 0.35 + 0.65,
              friction: 0.86,
              spring: 0.065,
            });
          }
        }
      }
    };

    initParticles();

    // Mouse & Touch listeners
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
      mouse.isActive = true;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.touches[0].clientX - rect.left;
        mouse.y = e.touches[0].clientY - rect.top;
        mouse.isActive = true;
      }
    };

    const handleMouseLeave = () => {
      mouse.x = -1000;
      mouse.y = -1000;
      mouse.isActive = false;
    };

    if (interactive) {
      container.addEventListener('mousemove', handleMouseMove);
      container.addEventListener('mouseleave', handleMouseLeave);
      container.addEventListener('touchmove', handleTouchMove, { passive: true });
      container.addEventListener('touchend', handleMouseLeave);
    }

    let time = 0;

    const render = () => {
      time += 0.03;
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Atmospheric effervescent micro-wobble
        const wobbleX = Math.sin(time + p.originY * 0.05) * 0.6;
        const wobbleY = Math.cos(time + p.originX * 0.05) * 0.6;

        // Interaction physics
        if (interactive && mouse.isActive) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < mouse.radius) {
            const force = (mouse.radius - dist) / mouse.radius;
            const angle = Math.atan2(dy, dx);
            const repelX = Math.cos(angle) * force * 16;
            const repelY = Math.sin(angle) * force * 16;

            p.vx -= repelX;
            p.vy -= repelY;
            p.radius = p.baseRadius * 1.4;
          } else {
            p.radius += (p.baseRadius - p.radius) * 0.1;
          }
        }

        // Spring return to origin
        const homeDx = (p.originX + wobbleX) - p.x;
        const homeDy = (p.originY + wobbleY) - p.y;

        p.vx += homeDx * p.spring;
        p.vy += homeDy * p.spring;
        p.vx *= p.friction;
        p.vy *= p.friction;

        p.x += p.vx;
        p.y += p.vy;

        // Render particle
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(0.5, p.radius), 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    const handleResize = () => {
      initParticles();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (interactive && container) {
        container.removeEventListener('mousemove', handleMouseMove);
        container.removeEventListener('mouseleave', handleMouseLeave);
        container.removeEventListener('touchmove', handleTouchMove);
        container.removeEventListener('touchend', handleMouseLeave);
      }
    };
  }, [text, particleSize, interactive]);

  return (
    <div
      ref={containerRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative w-full overflow-hidden flex items-center justify-center cursor-crosshair select-none ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full block pointer-events-auto" />
      {interactive && (
        <div
          className={`absolute bottom-2 right-4 text-[10px] tracking-widest uppercase font-mono transition-opacity duration-300 pointer-events-none ${
            isHovered ? 'text-[#D8FA00]/80 opacity-100' : 'text-white/40 opacity-0'
          }`}
        >
          Hover to disperse particles
        </div>
      )}
    </div>
  );
};
