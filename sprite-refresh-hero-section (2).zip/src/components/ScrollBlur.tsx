import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'motion/react';

interface ScrollBlurProps {
  children?: React.ReactNode;
  className?: string;
  maxBlur?: number; // Maximum blur in pixels (default: 12)
  maxScale?: number; // Depth scale factor (default: 1.04)
  parallaxOffset?: number; // Vertical parallax displacement (default: 40)
  targetRef?: React.RefObject<HTMLElement | null>;
  scrollProgress?: MotionValue<number>;
  direction?: 'in' | 'out' | 'focus-center'; // How the blur behaves
}

export const ScrollBlur: React.FC<ScrollBlurProps> = ({
  children,
  className = '',
  maxBlur = 10,
  maxScale = 1.03,
  parallaxOffset = 30,
  targetRef,
  scrollProgress,
  direction = 'focus-center',
}) => {
  const localRef = useRef<HTMLDivElement>(null);
  const activeRef = targetRef || localRef;

  const { scrollYProgress: defaultScroll } = useScroll({
    target: activeRef,
    offset: ['start end', 'end start'],
  });

  const progress = scrollProgress || defaultScroll;

  // Compute blur, scale, and y transforms based on the requested direction
  let blurVal: MotionValue<string>;
  let scaleVal: MotionValue<number>;
  let yVal: MotionValue<number>;
  let opacityVal: MotionValue<number>;

  if (direction === 'focus-center') {
    // Sharp in center of viewport, subtly blurred at entry and exit
    blurVal = useTransform(
      progress,
      [0, 0.25, 0.5, 0.75, 1],
      [`blur(${maxBlur}px)`, 'blur(2px)', 'blur(0px)', 'blur(2px)', `blur(${maxBlur}px)`]
    );
    scaleVal = useTransform(
      progress,
      [0, 0.5, 1],
      [1 / maxScale, 1, maxScale]
    );
    yVal = useTransform(
      progress,
      [0, 1],
      [-parallaxOffset, parallaxOffset]
    );
    opacityVal = useTransform(
      progress,
      [0, 0.15, 0.85, 1],
      [0.6, 1, 1, 0.6]
    );
  } else if (direction === 'in') {
    // Blurs as it enters, sharpens as it settles
    blurVal = useTransform(
      progress,
      [0, 0.5],
      [`blur(${maxBlur}px)`, 'blur(0px)']
    );
    scaleVal = useTransform(progress, [0, 0.5], [1 / maxScale, 1]);
    yVal = useTransform(progress, [0, 0.5], [-parallaxOffset, 0]);
    opacityVal = useTransform(progress, [0, 0.3], [0.4, 1]);
  } else {
    // Starts sharp, blurs out as it scrolls away
    blurVal = useTransform(
      progress,
      [0.5, 1],
      ['blur(0px)', `blur(${maxBlur}px)`]
    );
    scaleVal = useTransform(progress, [0.5, 1], [1, maxScale]);
    yVal = useTransform(progress, [0.5, 1], [0, parallaxOffset]);
    opacityVal = useTransform(progress, [0.7, 1], [1, 0.4]);
  }

  return (
    <motion.div
      ref={localRef}
      style={{
        filter: blurVal,
        scale: scaleVal,
        y: yVal,
        opacity: opacityVal,
      }}
      className={`will-change-[filter,transform,opacity] ${className}`}
    >
      {children}
    </motion.div>
  );
};
