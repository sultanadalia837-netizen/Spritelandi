import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { spriteAudio } from '../utils/audio';

interface CinematicRevealProps {
  onComplete?: () => void;
  onTransitionStart?: () => void;
}

interface BubbleParticle {
  x: number;
  y: number;
  r: number;
  vy: number;
  vx: number;
  alpha: number;
  life: number;
  maxLife: number;
}

export const SpriteCinematicReveal: React.FC<CinematicRevealProps> = ({
  onComplete,
  onTransitionStart,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [isDone, setIsDone] = useState<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let animationId: number;
    let startTime: number | null = null;
    const DURATION = 1750; // Buttery, crisp loading timeline

    let w = window.innerWidth || 1440;
    let h = window.innerHeight || 1080;

    const updateSize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    updateSize();
    window.addEventListener('resize', updateSize);

    const bubbles: BubbleParticle[] = [];
    let lastAudioTime = 0;
    let transitionTriggered = false;

    const render = (now: number) => {
      if (!startTime) startTime = now;
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / DURATION);

      // Smooth custom easing
      const easedT = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      const currentPct = Math.min(100, Math.floor(easedT * 100));
      setProgress(currentPct);

      // Audio bubble fizz interval
      if (now - lastAudioTime > 240 && t < 0.94) {
        spriteAudio.playFizzBubble();
        lastAudioTime = now;
      }

      const cx = w / 2;
      const cy = h / 2;
      const minDim = Math.min(w, h);

      // 1. Deep Electric Sprite Green Gradient
      const bgGradient = ctx.createRadialGradient(cx, cy * 0.9, minDim * 0.08, cx, cy, Math.max(w, h) * 0.85);
      bgGradient.addColorStop(0, '#00A850');
      bgGradient.addColorStop(0.5, '#007A38');
      bgGradient.addColorStop(1, '#004A22');
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, w, h);

      // 2. Liquid Central Droplet Geometry
      const baseDropRadius = Math.max(40, minDim * 0.11) * (0.9 + easedT * 0.18);
      const numNodes = 20;
      const dropPoints: { x: number; y: number }[] = [];
      const timeSec = elapsed / 1000;

      for (let i = 0; i < numNodes; i++) {
        const angle = (i / numNodes) * Math.PI * 2;
        const wobble1 = Math.sin(angle * 3 + timeSec * 5.5) * (baseDropRadius * 0.05);
        const wobble2 = Math.cos(angle * 4 - timeSec * 6.5) * (baseDropRadius * 0.035);
        const r = baseDropRadius + wobble1 + wobble2;

        dropPoints.push({
          x: cx + Math.cos(angle) * r,
          y: cy - minDim * 0.04 + Math.sin(angle) * r,
        });
      }

      // Outer Citrus Caustic Halo
      ctx.save();
      const dropCenterY = cy - minDim * 0.04;
      const haloGrad = ctx.createRadialGradient(cx, dropCenterY, baseDropRadius * 0.6, cx, dropCenterY, baseDropRadius * 1.5);
      haloGrad.addColorStop(0, 'rgba(255, 235, 0, 0.45)');
      haloGrad.addColorStop(0.5, 'rgba(167, 228, 51, 0.2)');
      haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = haloGrad;
      ctx.beginPath();
      ctx.arc(cx, dropCenterY, baseDropRadius * 1.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Fluid Droplet Body
      ctx.save();
      ctx.beginPath();
      const firstMid = {
        x: (dropPoints[0].x + dropPoints[numNodes - 1].x) / 2,
        y: (dropPoints[0].y + dropPoints[numNodes - 1].y) / 2,
      };
      ctx.moveTo(firstMid.x, firstMid.y);

      for (let i = 0; i < numNodes; i++) {
        const nextIdx = (i + 1) % numNodes;
        const midX = (dropPoints[i].x + dropPoints[nextIdx].x) / 2;
        const midY = (dropPoints[i].y + dropPoints[nextIdx].y) / 2;
        ctx.quadraticCurveTo(dropPoints[i].x, dropPoints[i].y, midX, midY);
      }
      ctx.closePath();

      // Liquid refractive gradient
      const liquidGrad = ctx.createRadialGradient(
        cx - baseDropRadius * 0.35,
        dropCenterY - baseDropRadius * 0.35,
        baseDropRadius * 0.1,
        cx,
        dropCenterY,
        baseDropRadius * 1.2
      );
      liquidGrad.addColorStop(0, '#FFFFFF');
      liquidGrad.addColorStop(0.2, '#FFE500'); // Lemon-lime yellow
      liquidGrad.addColorStop(0.55, '#85D829'); // Crisp lime
      liquidGrad.addColorStop(0.85, '#009B4D');
      liquidGrad.addColorStop(1, '#006E34');
      ctx.fillStyle = liquidGrad;
      ctx.fill();

      // Glass rim stroke
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = Math.max(1.8, minDim * 0.004);
      ctx.stroke();
      ctx.restore();

      // Specular Light Curved Reflection
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(
        cx - baseDropRadius * 0.32,
        dropCenterY - baseDropRadius * 0.35,
        baseDropRadius * 0.35,
        baseDropRadius * 0.16,
        -Math.PI / 4,
        0,
        Math.PI * 2
      );
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.fill();
      ctx.restore();

      // Ambient fizzy micro bubbles
      if (Math.random() < 0.6 && bubbles.length < 24) {
        bubbles.push({
          x: cx + (Math.random() - 0.5) * (baseDropRadius * 1.2),
          y: dropCenterY + baseDropRadius * 0.6,
          r: Math.random() * 2.5 + 1,
          vy: Math.random() * 2.2 + 1.2,
          vx: (Math.random() - 0.5) * 0.6,
          alpha: Math.random() * 0.7 + 0.3,
          life: 0,
          maxLife: Math.random() * 40 + 20,
        });
      }

      ctx.save();
      for (let i = bubbles.length - 1; i >= 0; i--) {
        const b = bubbles[i];
        b.y -= b.vy;
        b.x += b.vx;
        b.life++;

        const bAlpha = (1 - b.life / b.maxLife) * b.alpha;
        if (b.life >= b.maxLife) {
          bubbles.splice(i, 1);
          continue;
        }

        ctx.fillStyle = `rgba(255, 255, 255, ${bAlpha})`;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Trigger start of transition right as progress completes
      if (t >= 0.98 && !transitionTriggered) {
        transitionTriggered = true;
        spriteAudio.playRefreshBurst();
        if (onTransitionStart) onTransitionStart();
        setIsTransitioning(true);
      }

      if (t < 1) {
        animationId = requestAnimationFrame(render);
      } else {
        setTimeout(() => {
          setIsDone(true);
          if (onComplete) onComplete();
        }, 850);
      }
    };

    animationId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', updateSize);
    };
  }, [onComplete, onTransitionStart]);

  if (isDone) return null;

  return (
    <div
      id="sprite-global-website-loader"
      className="fixed inset-0 z-50 pointer-events-none select-none flex items-center justify-center overflow-hidden w-screen h-screen"
      style={{ transform: 'translateZ(0)' }}
    >
      {/* 1. TOP & BOTTOM SPLIT CURTAIN REVEAL WIPE */}
      <motion.div
        initial={{ scaleY: 1 }}
        animate={{ scaleY: isTransitioning ? 0 : 1 }}
        transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1], delay: 0.05 }}
        style={{ transformOrigin: 'top center' }}
        className="absolute top-0 left-0 right-0 h-1/2 bg-[#005c2a] z-40"
      />
      <motion.div
        initial={{ scaleY: 1 }}
        animate={{ scaleY: isTransitioning ? 0 : 1 }}
        transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1], delay: 0.05 }}
        style={{ transformOrigin: 'bottom center' }}
        className="absolute bottom-0 left-0 right-0 h-1/2 bg-[#005c2a] z-40"
      />

      {/* 2. SOLID FRESH SPRITE GREEN CANVAS */}
      <motion.div
        className="absolute inset-0 w-full h-full will-change-transform z-10"
        initial={{ opacity: 1, scale: 1 }}
        animate={{
          opacity: isTransitioning ? 0 : 1,
          scale: isTransitioning ? 1.06 : 1,
        }}
        transition={{
          duration: 0.85,
          ease: [0.19, 1, 0.22, 1],
        }}
      >
        <canvas ref={canvasRef} className="w-full h-full block" />
      </motion.div>

      {/* 3. EXPANDING LIQUID APERTURE WAVE */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0.95 }}
            animate={{ scale: 18, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.85,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="absolute z-30 w-32 h-32 rounded-full border-4 border-white/90 pointer-events-none shadow-[0_0_60px_rgba(255,229,0,0.85)]"
            style={{
              background:
                'radial-gradient(circle, rgba(255,255,255,0.45) 0%, rgba(255,229,0,0.25) 40%, rgba(0,148,72,0) 75%)',
            }}
          />
        )}
      </AnimatePresence>

      {/* 4. AMPLIFIED PRELOADER UI OVERLAY (Gauge + Kinetic Counter + Progress Rail) */}
      <motion.div
        className="relative z-20 flex flex-col items-center justify-center pointer-events-none max-w-sm w-full px-6"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{
          scale: isTransitioning ? 1.15 : 1,
          opacity: isTransitioning ? 0 : 1,
        }}
        transition={{
          duration: isTransitioning ? 0.45 : 0.5,
          ease: [0.19, 1, 0.22, 1],
        }}
      >
        {/* Brand Tagline */}
        <div className="flex items-center gap-2 mb-4 font-mono text-[11px] uppercase tracking-[0.3em] text-[#D8FA00]/90">
          <span className="w-2 h-2 rounded-full bg-[#D8FA00] animate-ping" />
          <span>OBEY YOUR THIRST</span>
        </div>

        {/* Big Crisp Monospace Number Counter */}
        <div className="flex items-baseline font-lilita text-white select-none drop-shadow-[0_4px_16px_rgba(0,0,0,0.4)]">
          <span
            className="tracking-normal leading-none font-bold"
            style={{
              fontSize: 'clamp(44px, 10vw, 68px)',
            }}
          >
            {String(progress).padStart(2, '0')}
          </span>
          <span
            className="text-[#FFE500] font-sans font-black ml-1"
            style={{
              fontSize: 'clamp(20px, 4.5vw, 28px)',
            }}
          >
            %
          </span>
        </div>

        {/* Sleek Progress Rail & Liquid Glow Fill */}
        <div className="w-full max-w-[240px] h-1.5 rounded-full bg-white/20 backdrop-blur-sm overflow-hidden mt-4 p-[1px] border border-white/30 shadow-[inset_0_1px_3px_rgba(0,0,0,0.3)]">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E9FF47] to-[#FFFFFF] shadow-[0_0_12px_rgba(216,250,0,0.8)]"
            style={{ width: `${progress}%` }}
            transition={{ ease: 'linear' }}
          />
        </div>

        {/* Micro Status */}
        <div className="mt-3 text-center text-white/60 font-mono text-[10px] tracking-widest uppercase">
          {progress < 40 ? 'Chilling Ingredients...' : progress < 85 ? 'Carbonating Flavor...' : 'Ready To Refresh'}
        </div>
      </motion.div>
    </div>
  );
};
